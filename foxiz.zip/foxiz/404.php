<?php
/** Don't load directly */
defined( 'ABSPATH' ) || exit;

get_header();
foxiz_page_404();
get_footer();