<?php
/*
Template Name: Reading List
*/

defined( 'ABSPATH' ) || exit;

get_header();
foxiz_render_reading_list_template();
get_footer();
