<?php
/** Don't load directly */
defined( 'ABSPATH' ) || exit;

?>
</div>
<?php foxiz_render_footer();  ?>
</div>
<?php wp_footer(); ?>
</body>
</html>