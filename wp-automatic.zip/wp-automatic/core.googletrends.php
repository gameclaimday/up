<?php
//docs https://learn.microsoft.com/en-us/bing/search-apis/bing-news-search/reference/query-parameters

// modify camp on the go
$campaign->camp_type = 'Feeds';
$campaign->camp_sub_type = 'GoogleTrends';

 

// feeds class
require_once 'core.feeds.php';